﻿using Anonymous.Classes;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Security.Cryptography;
using System.IO.Compression;
using Anonymous.Classes;

namespace Anonymous
{
    public partial class About : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ltlBuildChecksum.Text = checksumFileLogic();
            }
        }

        /*
         should user have password to login (or use google login only?)
         each user has a public key and private key
         they can message each other but private key decodes the message
         private key is combination of user's password and...??? should not store EVERYTHING in database
         maybe user's password is only confirmed, but there after, it's a hash of a second password that's never revealed?


        login via google integration
        user has password but system generates private key from google user id plus password
        private key is for private messaging with another user
        is encrypting meta data possible or necessary? (message sent time, to recipient ID, etc.)

        option to destory all history? would set private key to new.

        when sending message, a copy is encrypted with sender's public key, and another encyprted to receipient's public key. either side can destory their copy, but a copy would exist encrypted from the other user.
         */

        private string checksumFileLogic()
        {
            
            string zipFilePath = ConfigurationManager.AppSettings["AppPathInWwwroot"] + "anonymousBuildFiles.zip";

            if (!File.Exists(zipFilePath))
            {

                foreach (string filename in Utility.ZipFileListForChecksumComparison())
                {
                    if (File.Exists(zipFilePath))
                    {
                        using (ZipArchive zip = ZipFile.Open(zipFilePath, ZipArchiveMode.Update))
                        {
                            zip.CreateEntryFromFile(ConfigurationManager.AppSettings["AppPathInWwwroot"] + filename, filename);
                        }
                    }
                    else
                    {
                        using (ZipArchive zip = ZipFile.Open(zipFilePath, ZipArchiveMode.Create))
                        {
                            zip.CreateEntryFromFile(ConfigurationManager.AppSettings["AppPathInWwwroot"] + filename, filename);
                        }
                    }
                }


            }

            using (MD5 md5 = MD5.Create())
            {
                using (FileStream stream = File.OpenRead(zipFilePath))
                {
                    byte[] hash = md5.ComputeHash(stream);
                    return BitConverter.ToString(hash).Replace("-", "").ToLowerInvariant();
                }
            }
        }

    }
}