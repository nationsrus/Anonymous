﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Anonymous.Classes;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Security.Cryptography;

namespace Anonymous
{
    public partial class Register : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnRegisterOnClick(object sender, EventArgs e)
        {

            if (Db.Common.DoesEmailAlreadyExistInDb(tbxEmail.Text.ToLower().Trim(), out byte[] encryptedEmail, out DataSet dataSet))
            {
                lblSuccessmMsg.Text = "Email already exists in our system. Go to <a href='login'>Login</a> by <a href='login'>clicking here.</a>";
            }
            else
            {
                List<SqlParameter> sqlParameters = new List<SqlParameter>();
                SqlParameter sqlParameter = new SqlParameter();
                sqlParameters = new List<SqlParameter>();
                sqlParameter = new SqlParameter();
                sqlParameter.ParameterName = "@email";
                sqlParameter.Value = encryptedEmail;
                sqlParameters.Add(sqlParameter);

                sqlParameter = new SqlParameter();
                sqlParameter.ParameterName = "@encryptedPassword";
                sqlParameter.Value = BCrypt.Net.BCrypt.EnhancedHashPassword(tbxPassword1.Text); ;
                sqlParameters.Add(sqlParameter);

                string hashedPassword = System.Text.Encoding.Default.GetString(Security.Hash(tbxPassword1.Text, tbxEmail.Text.ToLower().Trim() + ConfigurationManager.AppSettings["AppSalt"]));

                string publicOnlyKeyXML = string.Empty, strEncryptedPublicPrivateKeyXML = string.Empty;

                using (var rsa = new RSACryptoServiceProvider(1024))
                {
                    try
                    {
                        string publicPrivateKeyXML = rsa.ToXmlString(true);
                        strEncryptedPublicPrivateKeyXML = Security.EncryptStringAES(rsa.ToXmlString(true), hashedPassword);
                        publicOnlyKeyXML = rsa.ToXmlString(false);
                    }
                    finally
                    {
                        rsa.PersistKeyInCsp = false;
                    }
                }

                sqlParameter = new SqlParameter();
                sqlParameter.ParameterName = "@encryptedPrivateKey";
                sqlParameter.Value = strEncryptedPublicPrivateKeyXML;
                sqlParameters.Add(sqlParameter);

                sqlParameter = new SqlParameter();
                sqlParameter.ParameterName = "@PublicKey";
                sqlParameter.Value = publicOnlyKeyXML;
                sqlParameters.Add(sqlParameter);

                Db.ExecuteNonQuery("INSERT INTO anon(email,encryptedPassword,encryptedPrivateKey,PublicKey) VALUES(@email,@encryptedPassword,@encryptedPrivateKey,@PublicKey)", out bool boolDbError, out string strDbError, sqlParameters);

                lblSuccessmMsg.Text = "Account created. Go to <a href='login'>Login</a> by <a href='login'>clicking here.</a>";
            }
            
        }

    }
}