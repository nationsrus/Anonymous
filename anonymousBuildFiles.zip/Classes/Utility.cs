﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Anonymous.Classes;
using System.Data;

namespace Anonymous.Classes
{
    public class Utility
    {
        public static void ddlNationLoad(System.Web.UI.WebControls.DropDownList ddl)
        {
            ddl.DataSource = Db.ExecuteQuery("SELECT nationId,commonName FROM nation ORDER BY nationId", out bool boolDbError, out string strDbError);
            ddl.DataTextField = "commonName";
            ddl.DataValueField = "nationId";
            ddl.DataBind();
        }

        public static List<string> ZipFileListForChecksumComparison()
        {
            List<string> files = new List<string>();

            files.Add("About.aspx");
            files.Add("About.aspx.cs");
            files.Add("About.aspx.designer.cs");
            files.Add("anon.aspx");
            files.Add("anon.aspx.cs");
            files.Add("anon.aspx.designer.cs");
            files.Add("Anonymous.csproj");
            files.Add("Anonymous.sln");
            files.Add("Contact.aspx");
            files.Add("Contact.aspx.cs");
            files.Add("Contact.aspx.designer.cs");
            files.Add("Default.aspx");
            files.Add("Default.aspx.cs");
            files.Add("Default.aspx.designer.cs");
            files.Add("Friend.aspx");
            files.Add("Friend.aspx.cs");
            files.Add("Friend.aspx.designer.cs");
            files.Add("FriendMessages.aspx");
            files.Add("FriendMessages.aspx.cs");
            files.Add("FriendMessages.aspx.designer.cs");
            files.Add("Friends.aspx");
            files.Add("Friends.aspx.cs");
            files.Add("Friends.aspx.designer.cs");
            files.Add("Global.asax");
            files.Add("Global.asax.cs");
            files.Add("Login.aspx");
            files.Add("Login.aspx.cs");
            files.Add("Login.aspx.designer.cs");
            files.Add("Logout.aspx");
            files.Add("Logout.aspx.cs");
            files.Add("Logout.aspx.designer.cs");
            files.Add("Me.aspx");
            files.Add("Me.aspx.cs");
            files.Add("Me.aspx.designer.cs");
            files.Add("Messages.aspx");
            files.Add("Messages.aspx.cs");
            files.Add("Messages.aspx.designer.cs");
            files.Add("Nation.aspx");
            files.Add("Nation.aspx.cs");
            files.Add("Nation.aspx.designer.cs");
            files.Add("Post.aspx");
            files.Add("Post.aspx.cs");
            files.Add("Post.aspx.designer.cs");
            files.Add("Register.aspx");
            files.Add("Register.aspx.cs");
            files.Add("Register.aspx.designer.cs");
            files.Add("Site.Master");
            files.Add("Site.Master.cs");
            files.Add("Site.Master.designer.cs");
            files.Add("Site.Mobile.Master");
            files.Add("Site.Mobile.Master.cs");
            files.Add("Site.Mobile.Master.designer.cs");
            files.Add("ViewSwitcher.ascx");
            files.Add("ViewSwitcher.ascx.cs");
            files.Add("ViewSwitcher.ascx.designer.cs");
            files.Add("Classes/Common.cs");
            files.Add("Classes/Db.cs");
            files.Add("Classes/Security.cs");
            files.Add("Classes/Utility.cs");
            files.Add("Scripts/Main.js");
            files.Add("packages.config");

            return files;
        }

    }
}