﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace Anonymous.Classes
{
    public class Db
    {
        private static SqlConnection GetSqlConnection()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["DefaultConnectionString"].ConnectionString;
            var connection = new SqlConnection(connectionString);
            connection.Open();
            return connection;
        }
        public static int ExecuteNonQuery(string commandText, out bool boolDbError, out string strDbError, List<SqlParameter> sqlParameters = null, CommandType commandType = CommandType.Text)
        {
            boolDbError = false;
            strDbError = string.Empty;
            int affectedRows = 0;
            using (SqlConnection connection = GetSqlConnection())
            {
                using (SqlCommand command = new SqlCommand(commandText, connection))
                {
                    command.CommandType = commandType;

                    if (sqlParameters != null && sqlParameters.Count > 0)
                    {
                        foreach (SqlParameter sqlParameter in sqlParameters)
                        {
                            command.Parameters.Add(sqlParameter);
                        }
                    }

                    try { 
                        affectedRows = command.ExecuteNonQuery();
                    }
                    catch(Exception ex)
                    {
                        boolDbError = true;
                        strDbError = "Error executing command: " + ex.ToString();
                    }
                }
            }
            return affectedRows;
        }

        public static DataSet ExecuteQuery(string commandText, out bool boolDbError, out string strDbError, List<SqlParameter> sqlParameters = null, CommandType commandType = CommandType.Text)
        {
            boolDbError = false;
            strDbError = string.Empty;
            using (SqlConnection connection = GetSqlConnection())
            {
                using (SqlCommand command = new SqlCommand(commandText, connection))
                {
                    DataSet ds = new DataSet();
                    command.CommandType = commandType;

                    if (sqlParameters != null && sqlParameters.Count > 0)
                    {
                        foreach (SqlParameter sqlParameter in sqlParameters)
                        {
                            command.Parameters.Add(sqlParameter);
                        }
                    }

                    try
                    {
                        SqlDataAdapter da = new SqlDataAdapter(command);
                        da.Fill(ds);
                    }
                    catch (Exception ex)
                    {
                        boolDbError = true;
                        strDbError = "Error executing command: " + ex.ToString();
                    }
                    //connection.Close();// is this needed?
                    return ds;
                }
            }
        }

        public class StoredProcedures
        {
            public static DataSet AnonIdBySaltedGoogleUserId(out bool boolDbError, out string strDbError, List<SqlParameter> sqlParameters= null)
            {
                DataSet ds = new DataSet();
                ds = ExecuteQuery("AnonIdBySaltedGoogleUserId", out boolDbError, out strDbError, sqlParameters, CommandType.StoredProcedure);
                return ds;
            }

            public static DataSet AnonCreate(out bool boolDbError, out string strDbError, List<SqlParameter> sqlParameters = null)
            {
                DataSet ds = new DataSet();
                ds = ExecuteQuery("AnonCreate", out boolDbError, out strDbError, sqlParameters, CommandType.StoredProcedure);
                return ds;
            }

            public static DataSet AnonUpdateSaltedGoogleUserId(out bool boolDbError, out string strDbError, List<SqlParameter> sqlParameters = null)
            {
                DataSet ds = new DataSet();
                ds = ExecuteQuery("AnonUpdateSaltedGoogleUserId", out boolDbError, out strDbError, sqlParameters, CommandType.StoredProcedure);
                return ds;
            }
            
        }

        public class Common
        {
            public static bool DoesEmailAlreadyExistInDb(string strUnecryptedEmail, out byte[] hashedEmail, out DataSet dataSet)
            {
                hashedEmail = Security.Hash(strUnecryptedEmail);
                //check if email already exists in system
                List<SqlParameter> sqlParameters = new List<SqlParameter>();
                SqlParameter sqlParameter = new SqlParameter();
                sqlParameter.ParameterName = "@email";
                sqlParameter.Value = hashedEmail;
                sqlParameters.Add(sqlParameter);
                dataSet = Db.ExecuteQuery("SELECT anonId, encryptedPassword FROM anon WHERE email = @email", out bool boolDbError, out string strDbError, sqlParameters);
                if (dataSet.Tables.Count > 0 && dataSet.Tables[0].Rows.Count>0)
                { 
                    return true; 
                }
                else
                { 
                    return false; 
                }
            }

            public static bool AreEmailAndPasswordCorrect(string strUnecryptedEmail, string strPassword, out DataSet dataSet)
            {
                byte[] hashedEmail = Security.Hash(strUnecryptedEmail);
                byte[] hashedPassword = Security.Hash(strPassword);
                //check if email already exists in system
                List<SqlParameter> sqlParameters = new List<SqlParameter>();
                SqlParameter sqlParameter = new SqlParameter();
                sqlParameter.ParameterName = "@email";
                sqlParameter.Value = hashedEmail;
                sqlParameters.Add(sqlParameter);
                sqlParameter = new SqlParameter();
                sqlParameter.ParameterName = "@encryptedPassword";
                sqlParameter.Value = hashedPassword;
                sqlParameters.Add(sqlParameter);
                dataSet = Db.ExecuteQuery("SELECT anonId FROM anon WHERE email = @email AND encryptedPassword = @encryptedPassword", out bool boolDbError, out string strDbError, sqlParameters);
                if (dataSet.Tables.Count > 0 && dataSet.Tables[0].Rows.Count > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }

            public static DataSet AnonByAnonId(out bool boolDbError, out string strDbError, List<SqlParameter> sqlParameters = null)
            {

                return ExecuteQuery("SELECT * FROM anon WHERE anonId = @anonId", out boolDbError, out strDbError, sqlParameters);

            }
        }

    }
}