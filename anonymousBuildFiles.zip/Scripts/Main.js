﻿function hideShowFocus(id,focusId) {
    var x = document.getElementById(id);
    if (x.style.display === "none") {
        x.style.display = "block";
        var focusObj = document.getElementById(focusId);
        focusObj.focus();
    } else {
        x.style.display = "none";
    }
}

function hideShow(id) {
    var x = document.getElementById(id);
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
}